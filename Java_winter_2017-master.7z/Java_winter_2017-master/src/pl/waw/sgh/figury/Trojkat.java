package pl.waw.sgh.figury;

class Trojkat extends Figura {


    public Trojkat(double parA) {
        super(parA);
    }

    public Trojkat(double a, double h) {
        super(a, h);
    }

    @Override
    public double policzPole() {
        return (this.parA * super.parB) / 2;
    }
}
