package pl.waw.sgh.figury;

class TrojkatRownoboczny extends Trojkat {


    public TrojkatRownoboczny(double bok) {
        super(bok);
    }

    public TrojkatRownoboczny(double a, double h) {
        super(a, h);
    }

    public double obliczPole(double a) {
        return (super.parA) * Math.sqrt(3) / 4;
    }
}
