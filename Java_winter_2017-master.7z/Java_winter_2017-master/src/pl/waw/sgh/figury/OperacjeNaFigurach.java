package pl.waw.sgh.figury;

public class OperacjeNaFigurach {

    public static void main(String[] args) {
        Figura f1 = new TrojkatRownoboczny(4);
        System.out.println(f1.policzPole());

    }
}
