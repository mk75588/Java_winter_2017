package pl.waw.sgh.figury;

class Kwadrat extends Figura {


    public Kwadrat(double parA) {
        super(parA);
    }

    @Override
    public double policzPole() {
        return super.parA * super.parA;
    }
}
