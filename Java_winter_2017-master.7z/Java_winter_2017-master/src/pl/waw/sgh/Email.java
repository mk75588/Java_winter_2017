package pl.waw.sgh;

public class Email
{
    public static void main(String[] args) {
        final String EMAIL = "abcddfd@sgsg.pl";


    }
}
